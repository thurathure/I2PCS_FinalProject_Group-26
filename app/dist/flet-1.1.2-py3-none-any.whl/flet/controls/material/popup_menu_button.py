from dataclasses import field
from enum import Enum
from typing import Optional

from flet.controls.animation import AnimationStyle
from flet.controls.base_control import control
from flet.controls.border_radius import BorderRadiusValue
from flet.controls.box import BoxConstraints
from flet.controls.buttons import ButtonStyle, OutlinedBorder
from flet.controls.control import Control
from flet.controls.control_event import ControlEventHandler
from flet.controls.layout_control import LayoutControl
from flet.controls.padding import PaddingValue
from flet.controls.text_style import TextStyle
from flet.controls.types import (
    ClipBehavior,
    ColorValue,
    IconDataOrControl,
    MouseCursor,
    Number,
    StrOrControl,
)


class PopupMenuPosition(Enum):
    """
    Used to configure how the :class:`~flet.PopupMenuButton` positions its popup menu.
    """

    OVER = "over"
    """
    Menu is positioned over the anchor.
    """

    UNDER = "under"
    """
    Menu is positioned under the anchor.
    """


@control("PopupMenuItem")
class PopupMenuItem(Control):
    """
    A popup menu item.
    """

    content: Optional[StrOrControl] = None
    """
    A `Control` representing custom content of this menu item.
    """

    icon: Optional[IconDataOrControl] = None
    """
    An icon to draw before the text label of this menu item.
    """

    checked: Optional[bool] = None
    """
    Whether this menu item is checked.

    If set to `True`, a checkmark will be shown on the left of the
    :attr:`content`.
    """

    height: Number = 48.0
    """
    The minimum height of this menu item.
    """

    padding: Optional[PaddingValue] = None
    """
    The padding of this menu item.

    Defaults to `Padding.symmetric(horizontal=12)`.

    Note:
        The :attr:`height` value of this menu item may
        influence the applied padding.

        For example, if a `height` greater than the height of the sum of the padding
        and a :attr:`content` is provided, then the padding's
        effect will not be visible.
    """

    label_text_style: Optional[TextStyle] = None
    """
    The text style of the label of this menu item."""

    mouse_cursor: Optional[MouseCursor] = None
    """
    The cursor to be displayed when a mouse pointer enters or is hovering over this \
    item.
    """

    on_click: Optional[ControlEventHandler["PopupMenuItem"]] = None
    """
    Called when a user clicks on this menu item.
    """


@control("PopupMenuButton")
class PopupMenuButton(LayoutControl):
    """
    An icon button which displays a menu when clicked.

    ```python
    ft.PopupMenuButton(
        items=[
            ft.PopupMenuItem(content="Sm"),
            ft.PopupMenuItem(content="Med"),
            ft.PopupMenuItem(content="Lg"),
        ],
        menu_position=ft.PopupMenuPosition.UNDER,
    )
    ```

    """

    content: Optional[StrOrControl] = None
    """
    A `Control` that will be displayed instead of "more" icon.
    """

    items: list[PopupMenuItem] = field(default_factory=list)
    """
    A collection of `PopupMenuItem` controls to display in a dropdown menu.
    """

    icon: Optional[IconDataOrControl] = None
    """
    If provided, an icon to draw on the button.
    """

    bgcolor: Optional[ColorValue] = None
    """
    The menu's background color.
    """

    icon_color: Optional[ColorValue] = None
    """
    The `icon`'s color.
    """

    shadow_color: Optional[ColorValue] = None
    """
    The color used to paint the shadow below the menu.
    """

    icon_size: Optional[Number] = None
    """
    The `icon`'s size.
    """

    splash_radius: Optional[Number] = None
    """
    The splash radius.
    """

    elevation: Optional[Number] = None
    """
    The menu's elevation when opened.

    Defaults to `8`.
    """

    menu_position: Optional[PopupMenuPosition] = None
    """
    Defines position of the popup menu relative to the button.

    Defaults to `PopupMenuPosition.OVER`.
    """

    clip_behavior: ClipBehavior = ClipBehavior.NONE
    """
    The `content` will be clipped (or not) according to this option.
    """

    enable_feedback: Optional[bool] = None
    """
    Whether detected gestures should provide acoustic and/or haptic feedback.

    On Android, for example, setting this to `True` produce a click sound and a
    long-press will produce a short vibration.

    Defaults to `True`.
    """

    shape: Optional[OutlinedBorder] = None
    """
    The menu's shape.

    Defaults to `CircleBorder(radius=10.0)`.
    """

    border_radius: Optional[BorderRadiusValue] = None
    """
    The corner radius of the button's hover/splash highlight when it shows a
    custom :attr:`content` (rather than an :attr:`icon`).

    Without it the highlight is a sharp-cornered rectangle, which shows past
    a rounded `content`.
    """

    padding: PaddingValue = 8
    """
    The padding around the button's tappable area.

    This affects the button itself, not the spacing inside the popup menu.
    """

    menu_padding: Optional[PaddingValue] = None
    """
    The padding around the menu's contents.

    Use this to inset the list of popup menu entries from the menu's outer boundary.
    """

    style: Optional[ButtonStyle] = None
    """
    The button style used for the popup menu button itself.

    This customizes the appearance and interactive states of the anchor button, not
    the popup menu entries.
    """

    popup_animation_style: Optional[AnimationStyle] = None
    """
    The animation style used when the popup menu opens and closes.

    Use this to customize the menu's motion timing, curves, and related animation
    behavior.
    """

    size_constraints: Optional[BoxConstraints] = None
    """
    Size constraints applied to the popup menu.

    Use this to control the minimum and maximum size of the menu when it is shown.
    """

    on_open: Optional[ControlEventHandler["PopupMenuButton"]] = None
    """
    Called when the popup menu is shown.
    """

    on_cancel: Optional[ControlEventHandler["PopupMenuButton"]] = None
    """
    Called when the user dismisses/cancels the popup menu without selecting an item.
    """

    on_select: Optional[ControlEventHandler["PopupMenuButton"]] = None
    """
    Called when the user selects a popup menu item.

    The :attr:`flet.Event.data` property of the event handler argument contains the
    selected :class:`~flet.PopupMenuItem` control's ID as a string.
    """

    def __contains__(self, item):
        return item in self.items
